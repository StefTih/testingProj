package com.example.testingPr.testingProj

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class TestingProjApplication

fun main(args: Array<String>) {
	runApplication<TestingProjApplication>(*args)
}
