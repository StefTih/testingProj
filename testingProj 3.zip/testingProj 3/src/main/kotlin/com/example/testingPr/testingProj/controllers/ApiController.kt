package com.example.testingPr.testingProj.controllers

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("openBanking/api")
class ApiController {

    @GetMapping("/info")
    fun getInfo() :String = "Testing!"
}