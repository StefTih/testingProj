package com.example.testingPr.testingProj.datasource

import com.example.testingPr.testingProj.model.OpenBankApis

interface OpenBankingDataSource {

    fun retrieveAllApis(): Collection<OpenBankApis>
}