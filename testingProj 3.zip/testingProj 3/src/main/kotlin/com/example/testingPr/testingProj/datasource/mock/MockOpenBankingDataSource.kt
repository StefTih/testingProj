package com.example.testingPr.testingProj.datasource.mock

import com.example.testingPr.testingProj.datasource.OpenBankingDataSource
import com.example.testingPr.testingProj.model.OpenBankApis
import org.springframework.stereotype.Repository

@Repository
class MockOpenBankingDataSource: OpenBankingDataSource {

    val banks = listOf(
        OpenBankApis(1,"test","joke"),
        OpenBankApis(2,"test_2","joke_2"),
        OpenBankApis(3,"test_3","joke_3"))

    override fun retrieveAllApis(): Collection<OpenBankApis> {
        return banks
    }
}