package com.example.testingPr.testingProj.model

data class OpenBankApis (
        val apiId: Int,
        val apiName: String,
        val apiDescription: String
        )
