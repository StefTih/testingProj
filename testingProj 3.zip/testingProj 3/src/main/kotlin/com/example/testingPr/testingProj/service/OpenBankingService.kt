package com.example.testingPr.testingProj.service

import com.example.testingPr.testingProj.datasource.OpenBankingDataSource
import com.example.testingPr.testingProj.model.OpenBankApis
import org.springframework.stereotype.Service

@Service
class OpenBankingService(private val dataSource: OpenBankingDataSource) {

    fun getOpenBankingAPIs(): Collection<OpenBankApis> = dataSource.retrieveAllApis()

}