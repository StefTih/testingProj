package com.example.testingPr.testingProj

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TestingProjApplicationTests {

	@Test
	fun contextLoads() {
	}

}
