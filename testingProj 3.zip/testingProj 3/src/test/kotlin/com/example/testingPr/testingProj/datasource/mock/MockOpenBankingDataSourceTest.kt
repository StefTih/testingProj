package com.example.testingPr.testingProj.datasource.mock

import com.example.testingPr.testingProj.model.OpenBankApis
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

internal class MockOpenBankingDataSourceTest {

    private val mockDataSource = MockOpenBankingDataSource()
    private lateinit var openBankApis: Collection<OpenBankApis>

    @BeforeEach
    fun `set up`(){
        openBankApis = mockDataSource.retrieveAllApis()
    }

    @Test
    fun `should provide a collection of banks`() {
        assertThat(openBankApis).isNotEmpty
    }

    @Test
    fun `should provide some mocked data`() {

        assertThat(openBankApis).allMatch { it.apiDescription.isNotBlank() }
        assertThat(openBankApis).allMatch { it.apiName.isNotBlank() }
        assertThat(openBankApis).allMatch { it.apiId != 0 }
    }

    @Test
    fun `should provide some mock data`(){

        assertThat(openBankApis).allMatch { it.apiDescription.isNotBlank() }
        assertThat(openBankApis).anyMatch { it.apiName.isNotBlank() }
        assertThat(openBankApis).anyMatch { it.apiId != 0 }
    }
}