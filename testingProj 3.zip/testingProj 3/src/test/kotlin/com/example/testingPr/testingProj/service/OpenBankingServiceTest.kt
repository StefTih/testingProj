package com.example.testingPr.testingProj.service

import com.example.testingPr.testingProj.datasource.OpenBankingDataSource
import com.example.testingPr.testingProj.model.OpenBankApis
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

internal class OpenBankingServiceTest {

    private lateinit var openBankApis: Collection<OpenBankApis>
    private val dataSource: OpenBankingDataSource = mockk(relaxed = true)
    private val openBankingService = OpenBankingService(dataSource)

    @BeforeEach
    fun `set up`(){
        openBankApis = openBankingService.getOpenBankingAPIs()
    }

    @Test
    fun `should call its data source to retrieve openBankingApi`(){
        every { dataSource.retrieveAllApis() } returns emptyList<>()

        verify { dataSource.retrieveAllApis() }
    }
}